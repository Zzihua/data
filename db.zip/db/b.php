<?php
include("auth.php");
include("template.php");

head("訂單管理系統");
horizontal_bar();
menu("$username 您好!!");
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

        <!-- jQuery v1.9.1 -->
    <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
    <!-- DataTables v1.10.16 -->
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" />
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css">

    <title>訂單管理</title>
  </head>
  <body>




    <center><h1>進貨訂單管理</h1></center>

    <div class="container">
    <div class='row'><div id='userModal'><form method='post' id='master_form' enctype='multipart/form-data'>																					
	<label>序號</label>
	<input type='text' name='seq' id='seq' class='form-control' />
	<br />
	<label>訂單代號</label>
	<input type='text' name='orderid' id='orderid' class='form-control' />
	<br />
	<label>採購人員代號</label>
	<input type='text' name='empid' id='empid' class='form-control' />
	<br /> 
	<label>供應商代號</label>
	<input type='text' name='supid' id='supid' class='form-control' />
	<br /> 
	<label>採購日期</label>
	<input type='text' name='purdate' id='purdate' class='form-control' />
	<br /> 
	<input type='hidden' name='course_id' id='course_id' />
	<input type='hidden' name='operation' id='operation' />							

	<div align=right><input type='submit' name='action' id='action' class='btn btn-primary' value='Add' />
	<button type='button' class='btn btn-danger' data-bs-dismiss='modal'>Close</button>
	<button type='button' id='detail_button' data-toggle='modal' data-target='#DetailModal' class='btn btn-success btn-lg'>DetailModal</button>
	</div>
	</form></div><div id='dynamic'>
<table cellpadding='0' cellspacing='0' border='0'  id='example' class='table table-striped table-bordered'>
	<thead>
		<tr>
		<th><B>序號</B></th>
        <th><B>訂單編號</B></th>
        <th><B>採購人員</B></th>
        <th><B>供應商名稱</B></th>
        <th><B>採購日期</B></th>
		
		
		</tr>
	</thead>
	
	
</table>







<?php
  
  function display_form($op,$oderid)
  {

      if ($op==3)
      {
        $oderid="";
        $empid="";
        $supid="";
        $purdate="";

        $op=4;

      }
      else
      {
              include("connectdb.php");
              $sql = "SELECT orderid,empid,supid,purdate FROM come where orderid='$orderid'";

              $result =$connect->query($sql);

              /* fetch associative array */
              if ($row = $result->fetch_assoc()) {
                  $orderid=$row['orderid'];
                  $empid=$row['empid'];
                  $supid=$row['supid'];
                  $purdate=$row['purdate'];
              }
                $op=2;
      }


      echo "<form action=b.php method=post>";
      echo "<input type=hidden name=op value=$op>";
      echo "<div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>員工代號</label>
              <input type='text' class='form-control' name=empid id='empid' placeholder='請輸入員工代號' value=$empid>
            </div>
            
            <div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>員工名稱</label>
              <input type='text' class='form-control' name=empname id='empname' placeholder='請輸入員工名稱' value=$empname>
            </div>
            <div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>現任職稱</label>
              <input type='text' class='form-control' name=jobtitle id='jobtitle' placeholder='請輸入現任職稱' value=$jobtitle>
            </div>";
      echo " <div class='col-auto'>
              <button type='submit' class='btn btn-info mb-3'>儲存</button>           
              <button type='reset' class='btn btn-warning mb-3'>reset</button>                            
            </div>";
      echo "</form>";

  }


    if(isset($_REQUEST['op']))
    {
      $op=$_REQUEST['op'];   

      
      switch ($op)
      {
        case 1:  //修改
              $empid=$_REQUEST['empid']; 
              display_form($op,$empid);
              break;      
        case 2:  //修改資料
                $empid=$_REQUEST['empid'];
              $empname=$_REQUEST['empname'];
              $jobtitle=$_REQUEST['jobtitle'];

                  $sql="update employee 
                          set empid='$empid',
                              empname='$empname',
                              jobtitle='$jobtitle'
                        where empid='$empid'";
                  include("connectdb.php");
                  include('dbutil.php');
                  execute_sql($sql);
              break;
        case 3: //新增
              $empid="";
                display_form($op,$empid);
              break;
        case 4: //新增資料
              $empid=$_REQUEST['empid'];
              $empname=$_REQUEST['empname'];
              $jobtitle=$_REQUEST['jobtitle'];

              $sql="insert into employee (empid,empname,jobtitle) values ('$empid','$empname','$jobtitle')";
              include("connectdb.php");
              include('dbutil.php');
              execute_sql($sql);
              break;      
        case 5: //刪除資料              
              $empid=$_REQUEST['empid'];              
            
              $sql="delete from employee where empid='$empid'";
              include("connectdb.php");
              include('dbutil.php');
              execute_sql($sql);
              break;

      }      
  
    }
  ?>





   

  </div>
  <script>
  	$( ".example" ).DataTable();
  </script>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php
footer();
?>