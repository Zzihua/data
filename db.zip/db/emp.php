<?php
include("auth.php");
include("template.php");

head("員工管理系統");
horizontal_bar();
menu("$username 您好!!");
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

        <!-- jQuery v1.9.1 -->
    <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
    <!-- DataTables v1.10.16 -->
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" />
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css">

    <title>員工管理</title>
  </head>
  <body>




    <center><h1>員工資料維護</h1></center>

    <div class="container">

    <?php
  
  function display_form($op,$empid)
  {

      if ($op==3)
      {
        $empid="";
        $empname="";
        $jobtitle="";
        $op=4;

      }
      else
      {
              include("connectdb.php");
              $sql = "SELECT empid,empname,jobtitle FROM employee where empid='$empid'";

              $result =$connect->query($sql);

              /* fetch associative array */
              if ($row = $result->fetch_assoc()) {
                  $empid=$row['empid'];
                  $empname=$row['empname'];
                  $jobtitle=$row['jobtitle'];
              }
                $op=2;
      }


      echo "<form action=emp.php method=post>";
      echo "<input type=hidden name=op value=$op>";
      echo "<div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>員工代號</label>
              <input type='text' class='form-control' name=empid id='empid' placeholder='請輸入員工代號' value=$empid>
            </div>
            
            <div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>員工名稱</label>
              <input type='text' class='form-control' name=empname id='empname' placeholder='請輸入員工名稱' value=$empname>
            </div>
            <div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>現任職稱</label>
              <input type='text' class='form-control' name=jobtitle id='jobtitle' placeholder='請輸入現任職稱' value=$jobtitle>
            </div>";
      echo " <div class='col-auto'>
              <button type='submit' class='btn btn-info mb-3'>儲存</button>           
              <button type='reset' class='btn btn-warning mb-3'>reset</button>                            
            </div>";
      echo "</form>";

  }


    if(isset($_REQUEST['op']))
    {
      $op=$_REQUEST['op'];   

      
      switch ($op)
      {
        case 1:  //修改
              $empid=$_REQUEST['empid']; 
              display_form($op,$empid);
              break;      
        case 2:  //修改資料
                $empid=$_REQUEST['empid'];
              $empname=$_REQUEST['empname'];
              $jobtitle=$_REQUEST['jobtitle'];

                  $sql="update employee 
                          set empid='$empid',
                              empname='$empname',
                              jobtitle='$jobtitle'
                        where empid='$empid'";
                  include("connectdb.php");
                  include('dbutil.php');
                  execute_sql($sql);
              break;
        case 3: //新增
              $empid="";
                display_form($op,$empid);
              break;
        case 4: //新增資料
              $empid=$_REQUEST['empid'];
              $empname=$_REQUEST['empname'];
              $jobtitle=$_REQUEST['jobtitle'];

              $sql="insert into employee (empid,empname,jobtitle) values ('$empid','$empname','$jobtitle')";
              include("connectdb.php");
              include('dbutil.php');
              execute_sql($sql);
              break;      
        case 5: //刪除資料              
              $empid=$_REQUEST['empid'];              
            
              $sql="delete from employee where empid='$empid'";
              include("connectdb.php");
              include('dbutil.php');
              execute_sql($sql);
              break;

      }      
  
    }
  ?>


                <p align=right>
                  <a href=dept.php?op=3><button type='button' class='btn btn-success'>新增 <i class='bi bi-alarm'></i></button></a>  </p>
                  <table class="example">
                  <thead>
                    <tr>
                      <td>員工代號</td>
                          <td>員工名稱</td>
                          <td>現任職稱</td>  
                          <td> edit</td>			
                          <td> delete</td>			
                    </tr>
                  </thead>
                  <tbody>

                  <?php

                        include("connectdb.php");
                        $sql = "SELECT empid,empname,jobtitle FROM employee";

                        $result =$connect->query($sql);

                        /* fetch associative array */
                        while ($row = $result->fetch_assoc()) {
                            //printf("%s (%s)\n", $row["Name"], $row["CountryCode"]);
                            $empid=$row['empid'];
                            $empname=$row['empname'];
                            $jobtitle=$row['jobtitle'];

                            echo "<tr><TD>$empid<td> $empname<TD>$jobtitle";    
                            echo "<TD><a href=emp.php?op=1&empid=$empid><button type='button' class='btn btn-dark'>修改 <i class='bi bi-alarm'></i></button></a>";
                            echo "<TD><a href=\"javascript:if(confirm('確實要刪除[$empname]嗎?'))location='emp.php?empid=$empid&op=5'\"><button type='button' class='btn btn-danger'>刪除 <i class='bi bi-trash'></i></button>";
                        }    


                    ?>
                    </tbody>
                    </table>


  </div>
  <script>
  	$( ".example" ).DataTable();
  </script>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php
footer();
?>