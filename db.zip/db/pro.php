<?php
include("auth.php");
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

        <!-- jQuery v1.9.1 -->
    <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
    <!-- DataTables v1.10.16 -->
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" />
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css">

    <title>產品管理</title>
  </head>
  <body>

 <?php

echo "歡迎 $username!!";
if($gender==1) echo "先生";
else          echo "小姐";

?>


    <h1>產品資料維護</h1>

    <div class="container">

  <?php
  
  function display_form($op,$prodname)
  {

      if ($op==3)
      {
        $prodname="";
        $proid="";
        $unitprice="";
        $cost="";
        $op=4;

      }
      else
      {
              include("connectdb.php");
              $sql = "SELECT prodname,proid,unitprice,cost FROM product where prodname='$prodname'";

              $result =$connect->query($sql);

              /* fetch associative array */
              if ($row = $result->fetch_assoc()) {
                  $prodname=$row['prodname'];
                  $proid=$row['proid'];
                  $unitprice=$row['unitprice'];
                  $cost=$row['cost'];
              }
                $op=2;
      }


      echo "<form action=pro.php method=post>";
      echo "<input type=hidden name=op value=$op>";
      echo "<div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>產品名稱</label>
              <input type='text' class='form-control' name=prodname id='prodname' placeholder='請輸入產品名稱' value=$prodname>
            </div>
            <div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>產品代號</label>
              <input type='text' class='form-control' name=proid id='proid' placeholder='請輸入產品代號' value=$proid>
            </div>
            <div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>單價</label>
              <input type='text' class='form-control' name=unitprice id='unitprice' placeholder='請輸入單價' value=$unitprice>
            </div>
            <div class='mb-3'>
              <label for='exampleFormControlInput1' class='form-label'>成本</label>
              <input type='text' class='form-control' name=cost id='cost' placeholder='請輸入成本' value=$cost>
            </div>";
            
      echo " <div class='col-auto'>
              <button type='submit' class='btn btn-info mb-3'>儲存</button>           
              <button type='reset' class='btn btn-warning mb-3'>reset</button>                            
            </div>";
      echo "</form>";

  }


    if(isset($_REQUEST['op']))
    {
      $op=$_REQUEST['op'];   

      
      switch ($op)
      {
        case 1:  //修改
              $prodname=$_REQUEST['prodname']; 
               display_form($op,$prodname);
              break;      
        case 2:  //修改資料
              $prodname=$_REQUEST['prodname'];
                $proid=$_REQUEST['proid'];
              
              $unitprice=$_REQUEST['unitprice'];
              $cost=$_REQUEST['cost'];

                  $sql="update product 
                          set prodname='$prodname',
                               proid='$proid',
                              unitprice='$unitprice',
                              cost='$cost'
                        where prodname='$prodname'";
                  include("connectdb.php");
                  include('dbutil.php');
                  execute_sql($sql);
              break;
        case 3: //新增
               $proid="";
                display_form($op,$proid);
              break;
        case 4: //新增資料
              $proname=$_REQUEST['prodname'];
              $proid=$_REQUEST['proid'];
              $unitprice=$_REQUEST['unitprice'];
              $cost=$_REQUEST['cost'];

              $sql="insert into product (prodname,proid,unitprice,cost) values ('$proid','$prodname','$unitprice','$cost')";
              include("connectdb.php");
              include('dbutil.php');
              execute_sql($sql);
              break;      
        case 5: //刪除資料              
              $proid=$_REQUEST['proid'];              
            
              $sql="delete from product where proid='$proid'";
              include("connectdb.php");
              include('dbutil.php');
              execute_sql($sql);
              break;

      }      
  
    }
  ?>


    <p align=right>
    <a href=pro.php?op=3><button type='button' class='btn btn-success'>新增 <i class='bi bi-alarm'></i></button></a>  </p>
    <table class="example">
  	<thead>
  		<tr>
  			<td>產品代號</td>
             <td>產品名稱</td>
             <td>單價</td> 
             <td>成本</td>  
             <td> edit</td>			
             <td> delete</td>			
  		</tr>
  	</thead>
  	<tbody>

    <?php


    
    include("connectdb.php");
    $sql = "SELECT proid,prodname,unitprice,cost FROM product";

    $result =$connect->query($sql);

    /* fetch associative array */
    while ($row = $result->fetch_assoc()) {
        //printf("%s (%s)\n", $row["Name"], $row["CountryCode"]);
        $prodname=$row['prodname'];
        $proid=$row['proid'];
        $unitprice=$row['unitprice'];
        $cost=$row['cost'];

        echo "<tr><TD>$prodname<td> $proid<TD>$unitprice<TD>$cost";    
        echo "<TD><a href=pro.php?op=1&proid=$proid><button type='button' class='btn btn-dark'>修改 <i class='bi bi-alarm'></i></button></a>";
        echo "<TD><a href=\"javascript:if(confirm('確實要刪除[$prodname]嗎?'))location='pro.php?proid=$proid&op=5'\"><button type='button' class='btn btn-danger'>刪除 <i class='bi bi-trash'></i></button>";
    }    

    
    ?>


</tbody>
  </table>


  </div>
  <script>
  	$( ".example" ).DataTable();
  </script>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>