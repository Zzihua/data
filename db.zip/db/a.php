<?php
include("auth.php");
include("template.php");

head("歡迎進銷存系統");
horizontal_bar();
menu("歡迎 $username !!");


footer();
?>